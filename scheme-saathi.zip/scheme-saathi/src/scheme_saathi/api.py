"""FastAPI app: chat endpoint, human confirmation endpoint, tracking views, static web UI."""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, confirmation
from .agent import SchemeSaathiAgent
from .i18n import LANGUAGES, strings_for
from .store import Store
from .tools import ToolBox

app = FastAPI(title="Scheme Saathi", version="0.1.0")
_state: dict = {}


def get_store() -> Store:
    if "store" not in _state:
        _state["store"] = Store(config.DB_PATH)
    return _state["store"]


def get_agent() -> SchemeSaathiAgent:
    if "agent" not in _state:
        store = get_store()
        _state["agent"] = SchemeSaathiAgent(store, toolbox=ToolBox(store))
    return _state["agent"]


class ChatIn(BaseModel):
    session_id: str = Field(min_length=8, max_length=64)
    message: str = Field(min_length=1, max_length=2000)
    lang: str = "hi-IN"


class ConfirmIn(BaseModel):
    session_id: str = Field(min_length=8, max_length=64)
    application_id: int
    token: str
    decision: str  # "confirm" | "cancel"
    lang: str = "hi-IN"


@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/api/languages")
def languages():
    return LANGUAGES


@app.get("/api/strings/{lang}")
def strings(lang: str):
    return strings_for(lang)


@app.post("/api/chat")
def chat(body: ChatIn):
    try:
        res = get_agent().chat(body.session_id, body.message, body.lang)
    except Exception as e:  # surface LLM/key problems clearly to the UI
        raise HTTPException(status_code=502, detail=f"Agent error: {type(e).__name__}: {e}") from e
    return {"reply": res.reply, "ui_events": res.ui_events}


@app.post("/api/confirm")
def confirm(body: ConfirmIn):
    """Human-driven channel. The LLM cannot reach this endpoint."""
    store, agent = get_store(), get_agent()
    result = confirmation.confirm(store, body.session_id, body.application_id, body.token,
                                  body.decision, portal=agent.tools.portal)
    s = strings_for(body.lang)
    if result["ok"] and result["status"] == "SUBMITTED":
        agent.notify(body.session_id, f"The citizen CONFIRMED application {body.application_id}. "
                     f"It was submitted. Reference {result['reference']}. Follow-ups scheduled: "
                     f"{result['followups']}. Tell them briefly and explain the follow-ups.")
        result["message"] = s["submitted"].format(ref=result["reference"])
    elif result["ok"]:
        agent.notify(body.session_id, f"The citizen CANCELLED application {body.application_id}. "
                     "Nothing was submitted.")
        result["message"] = s["cancelled"]
    else:
        result["message"] = s["failed"].format(err=result["error"])
    return result


@app.get("/api/applications")
def applications(session_id: str):
    return [{k: a[k] for k in ("id", "scheme_id", "status", "reference", "note")}
            for a in get_store().list_applications(session_id)]


@app.get("/api/followups")
def followups(session_id: str, due_only: bool = False):
    due = date.today().isoformat() if due_only else None
    return get_store().list_followups(session_id, due)


_web = Path(config.WEB_DIR) if config.WEB_DIR else Path(__file__).resolve().parents[2] / "web"
if _web.exists():
    app.mount("/static", StaticFiles(directory=_web), name="static")

    @app.get("/")
    def index():
        return FileResponse(_web / "index.html")


if os.environ.get("SAATHI_DEBUG_AUDIT") == "1":  # off by default
    @app.get("/api/audit")
    def audit(session_id: str):
        return get_store().audit_log(session_id)

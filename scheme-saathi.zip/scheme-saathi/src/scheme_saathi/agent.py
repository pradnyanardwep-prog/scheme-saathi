"""LLM agent: Anthropic tool-use loop around the ToolBox."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from . import config
from .prompts import system_prompt
from .store import Store
from .tools import TOOL_SCHEMAS, ToolBox

MAX_STEPS = 10
MAX_HISTORY = 60


@dataclass
class ChatResult:
    reply: str
    ui_events: list[dict] = field(default_factory=list)


def _block_to_dict(b) -> dict:
    if b.type == "text":
        return {"type": "text", "text": b.text}
    if b.type == "tool_use":
        return {"type": "tool_use", "id": b.id, "name": b.name, "input": b.input}
    raise ValueError(f"Unsupported block type {b.type}")


def _is_user_text(m: dict) -> bool:
    return m["role"] == "user" and isinstance(m["content"], str)


class SchemeSaathiAgent:
    def __init__(self, store: Store, client=None, model: str | None = None, toolbox: ToolBox | None = None):
        self.store = store
        self.tools = toolbox or ToolBox(store)
        self.model = model or config.MODEL
        if client is None:
            import anthropic  # imported lazily so tests/tools work without a key
            client = anthropic.Anthropic()
        self.client = client
        self.sessions: dict[str, list[dict]] = {}

    def _history(self, sid: str) -> list[dict]:
        h = self.sessions.setdefault(sid, [])
        # Trim from the front, but only at a plain user-text message so tool_use/tool_result pairs stay intact.
        while len(h) > MAX_HISTORY:
            nxt = next((i for i in range(1, len(h)) if _is_user_text(h[i])), None)
            if nxt is None:
                break
            del h[:nxt]
        return h

    def notify(self, sid: str, text: str) -> None:
        """Tell the model about a human-channel event (e.g. confirmation outcome)."""
        self._history(sid).append({"role": "user", "content": f"[SYSTEM NOTICE from app] {text}"})

    def chat(self, sid: str, text: str, lang: str = "hi-IN") -> ChatResult:
        history = self._history(sid)
        history.append({"role": "user", "content": text})
        ui_events: list[dict] = []
        reply = ""
        for _ in range(MAX_STEPS):
            resp = self.client.messages.create(
                model=self.model, max_tokens=1500, system=system_prompt(lang),
                tools=TOOL_SCHEMAS, messages=list(history))
            blocks = [_block_to_dict(b) for b in resp.content]
            history.append({"role": "assistant", "content": blocks})
            reply = "".join(b["text"] for b in blocks if b["type"] == "text") or reply
            if resp.stop_reason != "tool_use":
                break
            results = []
            for b in (b for b in blocks if b["type"] == "tool_use"):
                out, ui = self.tools.dispatch(sid, b["name"], b["input"])
                ui_events.extend(ui)
                results.append({"type": "tool_result", "tool_use_id": b["id"],
                                "content": json.dumps(out, ensure_ascii=False)})
            history.append({"role": "user", "content": results})
        return ChatResult(reply=reply.strip(), ui_events=ui_events)

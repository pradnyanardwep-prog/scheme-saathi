"""Tool definitions exposed to the LLM and their implementations."""
from __future__ import annotations

from datetime import date, timedelta

from . import confirmation, documents, eligibility, forms, knowledge
from .portal import MockPortal, Portal
from .store import Store

TOOL_SCHEMAS = [
    {
        "name": "update_profile",
        "description": "Save facts the citizen has told you (age, state, occupation, income, etc.). "
                       "Call whenever you learn new facts. Only use keys from the allowed field list; "
                       "values are validated and bad ones are returned in `rejected`.",
        "input_schema": {
            "type": "object",
            "properties": {"fields": {
                "type": "object",
                "description": "Map of field key -> value. Booleans as true/false, income as an integer "
                               "in INR, dates as YYYY-MM-DD, enums in English snake_case.",
                "additionalProperties": True}},
            "required": ["fields"],
        },
    },
    {
        "name": "check_eligibility",
        "description": "Run the deterministic eligibility rules on the saved profile. Returns, per scheme, "
                       "status eligible / not_eligible / need_more_info with reasons and the exact fields "
                       "still needed. Never judge eligibility yourself.",
        "input_schema": {"type": "object", "properties": {
            "scheme_ids": {"type": "array", "items": {"type": "string"},
                           "description": "Optional subset; omit to check all schemes."}}},
    },
    {
        "name": "get_document_checklist",
        "description": "Get the documents the citizen must carry/upload for a scheme (English + Hindi names).",
        "input_schema": {"type": "object", "properties": {"scheme_id": {"type": "string"}},
                         "required": ["scheme_id"]},
    },
    {
        "name": "prefill_form",
        "description": "Pre-fill the application form for a scheme from the saved profile and save it as a "
                       "DRAFT. Returns the filled form (sensitive values masked), missing required fields "
                       "and validation errors. Ask the citizen for anything missing, call update_profile, "
                       "then call prefill_form again.",
        "input_schema": {"type": "object", "properties": {"scheme_id": {"type": "string"}},
                         "required": ["scheme_id"]},
    },
    {
        "name": "request_submission",
        "description": "Ask the citizen to review and confirm a completed DRAFT. This does NOT submit: it "
                       "shows a confirmation card in the app that the citizen must press themselves. Only "
                       "call it after the citizen has said they want to apply and the draft has no missing "
                       "fields or errors.",
        "input_schema": {"type": "object", "properties": {"application_id": {"type": "integer"}},
                         "required": ["application_id"]},
    },
    {
        "name": "list_applications",
        "description": "List this citizen's applications with status and reference numbers.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "schedule_followup",
        "description": "Schedule a reminder for an application (e.g. 'check status', 'collect documents').",
        "input_schema": {"type": "object", "properties": {
            "application_id": {"type": "integer"},
            "in_days": {"type": "integer", "minimum": 1, "maximum": 365},
            "note": {"type": "string"}},
            "required": ["application_id", "in_days", "note"]},
    },
    {
        "name": "list_followups",
        "description": "List open follow-up reminders. Set due_only=true for those due today or overdue.",
        "input_schema": {"type": "object", "properties": {"due_only": {"type": "boolean"}}},
    },
    {
        "name": "record_status_update",
        "description": "Record a status the citizen reports for an already-SUBMITTED application.",
        "input_schema": {"type": "object", "properties": {
            "application_id": {"type": "integer"},
            "status": {"type": "string",
                       "enum": ["UNDER_REVIEW", "MORE_INFO_NEEDED", "APPROVED", "REJECTED"]},
            "note": {"type": "string"}},
            "required": ["application_id", "status"]},
    },
]


class ToolBox:
    def __init__(self, store: Store, portal: Portal | None = None, today: date | None = None):
        self.store = store
        self.portal = portal or MockPortal()
        self._today = today

    @property
    def today(self) -> date:
        return self._today or date.today()

    def dispatch(self, sid: str, name: str, args: dict) -> tuple[dict, list[dict]]:
        """Run a tool. Returns (result for the model, UI events for the human channel)."""
        fn = getattr(self, f"_t_{name}", None)
        if fn is None:
            return {"error": f"Unknown tool {name}"}, []
        try:
            ui: list[dict] = []
            result = fn(sid, ui, **(args or {}))
            self.store.audit(sid, f"tool:{name}", {"args": _redact(args)})
            return result, ui
        except TypeError as e:
            return {"error": f"Bad arguments: {e}"}, []

    # ---- tools
    def _t_update_profile(self, sid, ui, fields: dict):
        saved, rejected = {}, {}
        for k, v in (fields or {}).items():
            val, err = forms.coerce(k, v)
            if err:
                rejected[k] = err
            else:
                saved[k] = val
        profile = self.store.merge_profile(sid, saved) if saved else self.store.get_profile(sid)
        return {"saved": list(saved), "rejected": rejected, "profile": forms.masked_profile(profile)}

    def _t_check_eligibility(self, sid, ui, scheme_ids=None):
        profile = forms.derive(self.store.get_profile(sid), self.today)
        return {"results": eligibility.check_all(profile, scheme_ids),
                "disclaimer": "Screening only; final eligibility is decided by the authority."}

    def _t_get_document_checklist(self, sid, ui, scheme_id: str):
        return documents.checklist(scheme_id)

    def _t_prefill_form(self, sid, ui, scheme_id: str):
        profile = forms.derive(self.store.get_profile(sid), self.today)
        res = forms.prefill(scheme_id, profile)
        if "error" in res:
            return res
        app_id = self.store.upsert_draft(sid, scheme_id, res["form"])
        elig = eligibility.check_scheme(knowledge.get_scheme(scheme_id), profile)
        return {"application_id": app_id, "status": "DRAFT",
                "eligibility_status": elig["status"],
                "form": forms.masked_profile(res["form"]),
                "missing_required": res["missing_required"], "errors": res["errors"],
                "ready_for_confirmation": not res["missing_required"] and not res["errors"]
                                          and elig["status"] != "not_eligible"}

    def _t_request_submission(self, sid, ui, application_id: int):
        app = self.store.get_application(application_id)
        if not app or app["session_id"] != sid:
            return {"error": "Application not found"}
        if app["status"] not in ("DRAFT", "PENDING_CONFIRMATION"):
            return {"error": f"Application is already {app['status']}"}
        scheme = knowledge.get_scheme(app["scheme_id"])
        profile = forms.derive(self.store.get_profile(sid), self.today)
        check = forms.prefill(app["scheme_id"], profile)
        if check["missing_required"] or check["errors"]:
            return {"error": "Draft incomplete or invalid; call prefill_form and fix first",
                    "missing_required": check["missing_required"], "errors": check["errors"]}
        if eligibility.check_scheme(scheme, profile)["status"] == "not_eligible":
            return {"error": "Citizen is not eligible per the rules; do not submit"}
        token = confirmation.create_request(self.store, application_id)
        ui.append({"type": "confirm_request", "application_id": application_id, "token": token,
                   "scheme_id": scheme["id"], "scheme_name": scheme["name"],
                   "scheme_name_hi": scheme.get("name_hi"),
                   "rows": forms.display_rows(scheme["id"], app["form"])})
        return {"status": "awaiting_human_confirmation",
                "message": "A confirmation card is now on the citizen's screen. Tell them to review it "
                           "and press Confirm or Cancel. Nothing has been submitted yet."}

    def _t_list_applications(self, sid, ui):
        return {"applications": [
            {"application_id": a["id"], "scheme_id": a["scheme_id"], "status": a["status"],
             "reference": a["reference"], "note": a["note"]}
            for a in self.store.list_applications(sid)]}

    def _t_schedule_followup(self, sid, ui, application_id: int, in_days: int, note: str):
        app = self.store.get_application(application_id)
        if not app or app["session_id"] != sid:
            return {"error": "Application not found"}
        due = (self.today + timedelta(days=int(in_days))).isoformat()
        fid = self.store.add_followup(application_id, sid, due, note)
        return {"followup_id": fid, "due_date": due}

    def _t_list_followups(self, sid, ui, due_only: bool = False):
        fl = self.store.list_followups(sid, self.today.isoformat() if due_only else None)
        return {"today": self.today.isoformat(), "followups": fl}

    def _t_record_status_update(self, sid, ui, application_id: int, status: str, note: str = ""):
        app = self.store.get_application(application_id)
        if not app or app["session_id"] != sid:
            return {"error": "Application not found"}
        if app["status"] in ("DRAFT", "PENDING_CONFIRMATION", "CANCELLED"):
            return {"error": "Application has not been submitted"}
        if status not in ("UNDER_REVIEW", "MORE_INFO_NEEDED", "APPROVED", "REJECTED"):
            return {"error": "Invalid status"}
        self.store.update_application(application_id, status=status, note=note)
        if status in ("APPROVED", "REJECTED"):
            self.store.complete_followups(application_id)
        if status == "MORE_INFO_NEEDED":
            self.store.add_followup(application_id, sid,
                                    (self.today + timedelta(days=3)).isoformat(),
                                    note or "Provide the extra information requested")
        return {"application_id": application_id, "status": status}


def _redact(args: dict | None) -> dict:
    """Keep sensitive values out of the audit log."""
    flds = knowledge.fields()
    out = {}
    for k, v in (args or {}).items():
        if k == "fields" and isinstance(v, dict):
            out[k] = {fk: ("***" if flds.get(fk, {}).get("sensitive") else fv) for fk, fv in v.items()}
        else:
            out[k] = v
    return out

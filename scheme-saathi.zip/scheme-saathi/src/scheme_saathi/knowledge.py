"""Loads the scheme knowledge base (schemes.yaml)."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import yaml

DATA = Path(__file__).parent / "data" / "schemes.yaml"


@lru_cache(maxsize=1)
def load() -> dict:
    with open(DATA, encoding="utf-8") as f:
        return yaml.safe_load(f)


def schemes() -> list[dict]:
    return load()["schemes"]


def get_scheme(scheme_id: str) -> dict | None:
    return next((s for s in schemes() if s["id"] == scheme_id), None)


def fields() -> dict:
    return load()["fields"]


def documents() -> dict:
    return load()["documents"]

"""UI strings and speech language codes. The LLM itself handles conversation in any language."""

LANGUAGES = [
    {"code": "hi-IN", "name": "हिन्दी"}, {"code": "en-IN", "name": "English"},
    {"code": "mr-IN", "name": "मराठी"}, {"code": "ta-IN", "name": "தமிழ்"},
    {"code": "te-IN", "name": "తెలుగు"}, {"code": "bn-IN", "name": "বাংলা"},
    {"code": "gu-IN", "name": "ગુજરાતી"}, {"code": "kn-IN", "name": "ಕನ್ನಡ"},
    {"code": "ml-IN", "name": "മലയാളം"}, {"code": "pa-IN", "name": "ਪੰਜਾਬੀ"},
]

STRINGS = {
    "en": {"confirm_title": "Review before submitting", "confirm_btn": "Confirm and submit",
           "cancel_btn": "Cancel", "submitted": "Submitted. Reference number: {ref}",
           "cancelled": "Cancelled. Nothing was submitted.", "failed": "Could not submit: {err}",
           "placeholder": "Type or tap the mic", "mic": "Speak", "send": "Send",
           "applications": "My applications", "followups": "Follow-ups",
           "none": "Nothing here yet", "greeting": "Namaste! Tell me about yourself and I will find schemes you may qualify for.",
           "disclaimer": "Guidance only. Final eligibility is decided by the government office."},
    "hi": {"confirm_title": "जमा करने से पहले जाँच लें", "confirm_btn": "पुष्टि करें और जमा करें",
           "cancel_btn": "रद्द करें", "submitted": "जमा हो गया। संदर्भ संख्या: {ref}",
           "cancelled": "रद्द किया गया। कुछ भी जमा नहीं हुआ।", "failed": "जमा नहीं हो सका: {err}",
           "placeholder": "लिखें या माइक दबाकर बोलें", "mic": "बोलें", "send": "भेजें",
           "applications": "मेरे आवेदन", "followups": "फ़ॉलो-अप",
           "none": "अभी कुछ नहीं है", "greeting": "नमस्ते! अपने बारे में बताइए, मैं देखूँगा कि आप किन योजनाओं के पात्र हो सकते हैं।",
           "disclaimer": "यह केवल मार्गदर्शन है। अंतिम पात्रता सरकारी कार्यालय तय करता है।"},
    "mr": {"confirm_title": "सादर करण्यापूर्वी तपासा", "confirm_btn": "खात्री करा आणि सादर करा",
           "cancel_btn": "रद्द करा", "submitted": "सादर झाले. संदर्भ क्रमांक: {ref}",
           "cancelled": "रद्द केले. काहीही सादर झाले नाही.", "failed": "सादर करता आले नाही: {err}",
           "placeholder": "लिहा किंवा माइक दाबून बोला", "mic": "बोला", "send": "पाठवा",
           "applications": "माझे अर्ज", "followups": "पाठपुरावा",
           "none": "अजून काही नाही", "greeting": "नमस्कार! स्वतःबद्दल सांगा, मी तुम्हाला कोणत्या योजना लागू होतील ते शोधतो.",
           "disclaimer": "हे फक्त मार्गदर्शन आहे. अंतिम पात्रता शासकीय कार्यालय ठरवते."},
    "ta": {"confirm_title": "சமர்ப்பிக்கும் முன் சரிபார்க்கவும்", "confirm_btn": "உறுதி செய்து சமர்ப்பிக்கவும்",
           "cancel_btn": "ரத்து செய்", "submitted": "சமர்ப்பிக்கப்பட்டது. குறிப்பு எண்: {ref}",
           "cancelled": "ரத்து செய்யப்பட்டது. எதுவும் சமர்ப்பிக்கப்படவில்லை.", "failed": "சமர்ப்பிக்க முடியவில்லை: {err}",
           "placeholder": "தட்டச்சு செய்யவும் அல்லது மைக்கை அழுத்தவும்", "mic": "பேசுங்கள்", "send": "அனுப்பு",
           "applications": "என் விண்ணப்பங்கள்", "followups": "பின்தொடர்தல்",
           "none": "இன்னும் எதுவும் இல்லை", "greeting": "வணக்கம்! உங்களைப் பற்றி சொல்லுங்கள், உங்களுக்குப் பொருந்தும் திட்டங்களைத் தேடுகிறேன்.",
           "disclaimer": "இது வழிகாட்டுதல் மட்டுமே. இறுதித் தகுதியை அரசு அலுவலகம் தீர்மானிக்கும்."},
    "te": {"confirm_title": "సమర్పించే ముందు పరిశీలించండి", "confirm_btn": "నిర్ధారించి సమర్పించండి",
           "cancel_btn": "రద్దు చేయి", "submitted": "సమర్పించబడింది. రిఫరెన్స్ నంబర్: {ref}",
           "cancelled": "రద్దు చేయబడింది. ఏదీ సమర్పించబడలేదు.", "failed": "సమర్పించలేకపోయాము: {err}",
           "placeholder": "టైప్ చేయండి లేదా మైక్ నొక్కండి", "mic": "మాట్లాడండి", "send": "పంపు",
           "applications": "నా దరఖాస్తులు", "followups": "ఫాలో-అప్‌లు",
           "none": "ఇంకా ఏమీ లేదు", "greeting": "నమస్కారం! మీ గురించి చెప్పండి, మీకు వర్తించే పథకాలను చూస్తాను.",
           "disclaimer": "ఇది మార్గదర్శనం మాత్రమే. తుది అర్హతను ప్రభుత్వ కార్యాలయం నిర్ణయిస్తుంది."},
    "bn": {"confirm_title": "জমা দেওয়ার আগে দেখে নিন", "confirm_btn": "নিশ্চিত করুন ও জমা দিন",
           "cancel_btn": "বাতিল", "submitted": "জমা হয়েছে। রেফারেন্স নম্বর: {ref}",
           "cancelled": "বাতিল হয়েছে। কিছু জমা হয়নি।", "failed": "জমা দেওয়া যায়নি: {err}",
           "placeholder": "লিখুন বা মাইক চাপুন", "mic": "বলুন", "send": "পাঠান",
           "applications": "আমার আবেদন", "followups": "ফলো-আপ",
           "none": "এখনও কিছু নেই", "greeting": "নমস্কার! নিজের কথা বলুন, আমি দেখব আপনি কোন প্রকল্পের যোগ্য হতে পারেন।",
           "disclaimer": "এটি শুধু নির্দেশনা। চূড়ান্ত যোগ্যতা সরকারি দপ্তর ঠিক করে।"},
}


def strings_for(lang: str) -> dict:
    base = (lang or "hi").split("-")[0].lower()
    return STRINGS.get(base, STRINGS["hi"])

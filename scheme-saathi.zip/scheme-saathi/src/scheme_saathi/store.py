"""SQLite persistence: profiles, applications, follow-ups, audit log."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
  session_id TEXT PRIMARY KEY, data TEXT NOT NULL, updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, scheme_id TEXT NOT NULL,
  status TEXT NOT NULL, form TEXT NOT NULL, form_hash TEXT, token_hash TEXT,
  reference TEXT, note TEXT, created REAL NOT NULL, updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS followups (
  id INTEGER PRIMARY KEY AUTOINCREMENT, application_id INTEGER NOT NULL, session_id TEXT NOT NULL,
  due_date TEXT NOT NULL, note TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, session_id TEXT,
  event TEXT NOT NULL, detail TEXT);
"""

# Application lifecycle:
# DRAFT -> PENDING_CONFIRMATION -> SUBMITTED -> UNDER_REVIEW | MORE_INFO_NEEDED -> APPROVED | REJECTED
# (PENDING_CONFIRMATION -> CANCELLED / back to DRAFT if the form changes)


class Store:
    def __init__(self, path: str = ":memory:"):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.conn.executescript(SCHEMA)

    # ---- helpers
    def _exec(self, sql: str, args: tuple = ()):
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    def _all(self, sql: str, args: tuple = ()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    # ---- profile
    def get_profile(self, sid: str) -> dict:
        rows = self._all("SELECT data FROM profiles WHERE session_id=?", (sid,))
        return json.loads(rows[0]["data"]) if rows else {}

    def merge_profile(self, sid: str, updates: dict) -> dict:
        p = {**self.get_profile(sid), **updates}
        self._exec(
            "INSERT INTO profiles(session_id,data,updated) VALUES(?,?,?) "
            "ON CONFLICT(session_id) DO UPDATE SET data=excluded.data, updated=excluded.updated",
            (sid, json.dumps(p, ensure_ascii=False), time.time()),
        )
        return p

    # ---- applications
    def _app(self, row: dict) -> dict:
        row["form"] = json.loads(row["form"])
        return row

    def get_application(self, app_id: int) -> dict | None:
        rows = self._all("SELECT * FROM applications WHERE id=?", (app_id,))
        return self._app(rows[0]) if rows else None

    def list_applications(self, sid: str) -> list[dict]:
        rows = self._all("SELECT * FROM applications WHERE session_id=? ORDER BY id", (sid,))
        return [self._app(r) for r in rows]

    def upsert_draft(self, sid: str, scheme_id: str, form: dict) -> int:
        """One open draft per (session, scheme). Editing the form resets any pending confirmation."""
        now = time.time()
        rows = self._all(
            "SELECT id FROM applications WHERE session_id=? AND scheme_id=? "
            "AND status IN ('DRAFT','PENDING_CONFIRMATION')", (sid, scheme_id))
        blob = json.dumps(form, ensure_ascii=False, sort_keys=True)
        if rows:
            self._exec(
                "UPDATE applications SET form=?, status='DRAFT', form_hash=NULL, token_hash=NULL, "
                "updated=? WHERE id=?", (blob, now, rows[0]["id"]))
            return rows[0]["id"]
        cur = self._exec(
            "INSERT INTO applications(session_id,scheme_id,status,form,created,updated) "
            "VALUES(?,?,?,?,?,?)", (sid, scheme_id, "DRAFT", blob, now, now))
        return cur.lastrowid

    def update_application(self, app_id: int, **cols) -> None:
        cols["updated"] = time.time()
        sets = ", ".join(f"{k}=?" for k in cols)
        self._exec(f"UPDATE applications SET {sets} WHERE id=?", (*cols.values(), app_id))

    # ---- follow-ups
    def add_followup(self, app_id: int, sid: str, due_date: str, note: str) -> int:
        cur = self._exec(
            "INSERT INTO followups(application_id,session_id,due_date,note) VALUES(?,?,?,?)",
            (app_id, sid, due_date, note))
        return cur.lastrowid

    def list_followups(self, sid: str, due_on_or_before: str | None = None) -> list[dict]:
        sql = "SELECT * FROM followups WHERE session_id=? AND done=0"
        args: tuple = (sid,)
        if due_on_or_before:
            sql += " AND due_date<=?"
            args += (due_on_or_before,)
        return self._all(sql + " ORDER BY due_date", args)

    def complete_followups(self, app_id: int) -> None:
        self._exec("UPDATE followups SET done=1 WHERE application_id=?", (app_id,))

    # ---- audit
    def audit(self, sid: str | None, event: str, detail: dict | None = None) -> None:
        self._exec("INSERT INTO audit(ts,session_id,event,detail) VALUES(?,?,?,?)",
                   (time.time(), sid, event, json.dumps(detail or {}, ensure_ascii=False)))

    def audit_log(self, sid: str) -> list[dict]:
        return self._all("SELECT * FROM audit WHERE session_id=? ORDER BY id", (sid,))

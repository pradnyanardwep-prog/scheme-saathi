"""Portal adapter.

Most government portals have no public submission API. `MockPortal` simulates one so the whole
flow is demonstrable. In production, replace it with (a) an official API client where one exists,
or (b) an assisted-submission queue for a CSC / Gram Panchayat operator who files on the
citizen's behalf using the pre-filled data.
"""
from __future__ import annotations

import hashlib
import json
from typing import Protocol


class Portal(Protocol):
    def submit(self, scheme_id: str, form: dict) -> str:
        """Submit the form and return a reference/acknowledgement number."""


class MockPortal:
    def submit(self, scheme_id: str, form: dict) -> str:
        digest = hashlib.sha256(json.dumps([scheme_id, form], sort_keys=True).encode()).hexdigest()
        return f"MOCK-{scheme_id.upper()}-{digest[:8].upper()}"

"""Deterministic, three-valued eligibility rule engine.

Each rule evaluates to True / False / None (unknown, because the profile lacks the fact).
The LLM never decides eligibility; it only calls this engine and explains the result.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import knowledge


@dataclass
class Outcome:
    value: bool | None
    reasons: list[str] = field(default_factory=list)  # why it failed (or passed, for `any`)
    missing: set[str] = field(default_factory=set)    # profile fields needed to decide


def _compare(op: str, actual, expected) -> bool:
    if op == "eq":
        return actual == expected
    if op == "ne":
        return actual != expected
    if op == "gte":
        return actual >= expected
    if op == "lte":
        return actual <= expected
    if op == "between":
        return expected[0] <= actual <= expected[1]
    if op == "in":
        return actual in expected
    if op == "nin":
        return actual not in expected
    raise ValueError(f"Unknown operator: {op}")


def evaluate(node: dict, profile: dict) -> Outcome:
    if "all" in node:
        outs = [evaluate(n, profile) for n in node["all"]]
        missing = set().union(*(o.missing for o in outs))
        if any(o.value is False for o in outs):
            return Outcome(False, [r for o in outs if o.value is False for r in o.reasons], missing)
        return Outcome(None if any(o.value is None for o in outs) else True, [], missing)
    if "any" in node:
        outs = [evaluate(n, profile) for n in node["any"]]
        if any(o.value is True for o in outs):
            return Outcome(True)
        missing = set().union(*(o.missing for o in outs))
        if all(o.value is False for o in outs):
            return Outcome(False, [r for o in outs for r in o.reasons], missing)
        return Outcome(None, [], missing)
    # leaf
    key = node["field"]
    actual = profile.get(key)
    if actual is None:
        return Outcome(None, [], {key})
    ok = _compare(node["op"], actual, node["value"])
    why = node.get("why") or f"{key} {node['op']} {node['value']}"
    return Outcome(ok, [] if ok else [why])


def check_scheme(scheme: dict, profile: dict) -> dict:
    out = evaluate(scheme["eligibility"], profile)
    status = {True: "eligible", False: "not_eligible", None: "need_more_info"}[out.value]
    flds = knowledge.fields()
    return {
        "scheme_id": scheme["id"],
        "name": scheme["name"],
        "name_hi": scheme.get("name_hi"),
        "status": status,
        "benefit": scheme["benefit"],
        "benefit_hi": scheme.get("benefit_hi"),
        "portal": scheme.get("portal"),
        "notes": scheme.get("notes"),
        "reasons_not_eligible": out.reasons if status == "not_eligible" else [],
        "missing_fields": [
            {"key": k, "question_en": flds[k]["en"], "question_hi": flds[k]["hi"]}
            for k in sorted(out.missing)
        ] if status == "need_more_info" else [],
    }


def check_all(profile: dict, scheme_ids: list[str] | None = None) -> list[dict]:
    items = [s for s in knowledge.schemes() if not scheme_ids or s["id"] in scheme_ids]
    order = {"eligible": 0, "need_more_info": 1, "not_eligible": 2}
    results = [check_scheme(s, profile) for s in items]
    return sorted(results, key=lambda r: order[r["status"]])

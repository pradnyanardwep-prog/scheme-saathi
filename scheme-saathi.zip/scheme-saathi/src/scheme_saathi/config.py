import os

MODEL = os.environ.get("SAATHI_MODEL", "claude-sonnet-5-5")
DB_PATH = os.environ.get("SAATHI_DB", "./data/saathi.db")
WEB_DIR = os.environ.get("SAATHI_WEB", "")

"""Human-in-the-loop confirmation gate.

Design rules (the core safety property of this project):
  1. The LLM has NO tool that submits. It can only call `request_submission`, which moves an
     application to PENDING_CONFIRMATION and emits a one-time token to the *UI channel*
     (never into the model's context).
  2. Only `confirm()` below, called from a human-driven channel (web button / CLI prompt),
     can submit. It requires the token and re-verifies the form hash that the human was shown.
  3. Any edit to the form after the request resets the application to DRAFT and voids the token.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from datetime import date, timedelta

from .portal import MockPortal, Portal
from .store import Store

FOLLOWUP_SCHEDULE = [(7, "Check application status on the portal / with the CSC"),
                     (30, "Escalate or visit the help desk if no update yet")]


def _hash(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _tok_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_request(store: Store, app_id: int) -> str:
    """Move a DRAFT to PENDING_CONFIRMATION and return the one-time token (UI channel only)."""
    app = store.get_application(app_id)
    token = secrets.token_urlsafe(16)
    store.update_application(app_id, status="PENDING_CONFIRMATION",
                             form_hash=_hash(app["form"]), token_hash=_tok_hash(token))
    store.audit(app["session_id"], "submission_requested", {"application_id": app_id})
    return token


def confirm(store: Store, session_id: str, app_id: int, token: str, decision: str,
            portal: Portal | None = None, today: date | None = None) -> dict:
    portal = portal or MockPortal()
    today = today or date.today()
    app = store.get_application(app_id)
    if not app or app["session_id"] != session_id:
        return {"ok": False, "error": "Application not found"}
    if app["status"] != "PENDING_CONFIRMATION":
        return {"ok": False, "error": f"Application is {app['status']}, not awaiting confirmation"}
    if not token or not hmac.compare_digest(app["token_hash"] or "", _tok_hash(token)):
        store.audit(session_id, "confirm_bad_token", {"application_id": app_id})
        return {"ok": False, "error": "Invalid confirmation token"}

    if decision == "cancel":
        store.update_application(app_id, status="CANCELLED", token_hash=None)
        store.audit(session_id, "submission_cancelled", {"application_id": app_id})
        return {"ok": True, "status": "CANCELLED", "application_id": app_id}
    if decision != "confirm":
        return {"ok": False, "error": "decision must be 'confirm' or 'cancel'"}
    if _hash(app["form"]) != app["form_hash"]:
        store.update_application(app_id, status="DRAFT", token_hash=None, form_hash=None)
        return {"ok": False, "error": "Form changed after it was shown; please review again"}

    reference = portal.submit(app["scheme_id"], app["form"])
    store.update_application(app_id, status="SUBMITTED", reference=reference, token_hash=None)
    for days, note in FOLLOWUP_SCHEDULE:
        store.add_followup(app_id, session_id, (today + timedelta(days=days)).isoformat(), note)
    store.audit(session_id, "submitted", {"application_id": app_id, "reference": reference})
    return {"ok": True, "status": "SUBMITTED", "application_id": app_id, "reference": reference,
            "followups": [(today + timedelta(days=d)).isoformat() for d, _ in FOLLOWUP_SCHEDULE]}

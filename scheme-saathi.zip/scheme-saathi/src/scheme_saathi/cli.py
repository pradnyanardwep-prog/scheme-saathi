"""Terminal client: `saathi chat`. Confirmation is a typed human YES, outside the LLM."""
from __future__ import annotations

import argparse
import uuid

from . import config, confirmation
from .agent import SchemeSaathiAgent
from .i18n import strings_for
from .store import Store
from .tools import ToolBox


def _handle_confirm(agent, store, sid, ev, lang) -> None:
    s = strings_for(lang)
    print(f"\n=== {s['confirm_title']}: {ev['scheme_name']} ===")
    for r in ev["rows"]:
        print(f"  {r['label_hi'] if lang.startswith('hi') else r['label_en']}: {r['value']}")
    ans = input("Type YES to submit, anything else to cancel: ").strip().upper()
    decision = "confirm" if ans == "YES" else "cancel"
    res = confirmation.confirm(store, sid, ev["application_id"], ev["token"], decision,
                               portal=agent.tools.portal)
    if res["ok"] and res["status"] == "SUBMITTED":
        print(s["submitted"].format(ref=res["reference"]))
        agent.notify(sid, f"The citizen CONFIRMED application {ev['application_id']}. Submitted. "
                          f"Reference {res['reference']}. Follow-ups: {res['followups']}.")
    elif res["ok"]:
        print(s["cancelled"])
        agent.notify(sid, f"The citizen CANCELLED application {ev['application_id']}.")
    else:
        print(s["failed"].format(err=res["error"]))


def main() -> None:
    ap = argparse.ArgumentParser(prog="saathi")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("chat", help="Chat in the terminal")
    c.add_argument("--lang", default="hi-IN")
    c.add_argument("--session", default=None, help="Reuse a session id to resume profile/applications")
    f = sub.add_parser("followups", help="List open follow-ups for a session")
    f.add_argument("--session", required=True)
    f.add_argument("--due", action="store_true")
    args = ap.parse_args()

    store = Store(config.DB_PATH)
    if args.cmd == "followups":
        from datetime import date
        for fu in store.list_followups(args.session, date.today().isoformat() if args.due else None):
            print(f"{fu['due_date']}  app#{fu['application_id']}  {fu['note']}")
        return

    sid = args.session or uuid.uuid4().hex
    agent = SchemeSaathiAgent(store, toolbox=ToolBox(store))
    print(strings_for(args.lang)["greeting"], f"\n(session {sid}; Ctrl-C to quit)\n")
    try:
        while True:
            text = input("You: ").strip()
            if not text:
                continue
            res = agent.chat(sid, text, args.lang)
            for ev in res.ui_events:
                if ev["type"] == "confirm_request":
                    print(f"Saathi: {res.reply}")
                    _handle_confirm(agent, store, sid, ev, args.lang)
                    res.reply = ""
            if res.reply:
                print(f"Saathi: {res.reply}")
    except (KeyboardInterrupt, EOFError):
        print("\nNamaste!")


if __name__ == "__main__":
    main()

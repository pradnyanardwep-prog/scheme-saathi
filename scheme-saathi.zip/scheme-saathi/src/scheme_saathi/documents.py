"""Document checklist builder."""
from __future__ import annotations

from . import knowledge


def checklist(scheme_id: str) -> dict:
    scheme = knowledge.get_scheme(scheme_id)
    if not scheme:
        return {"error": f"Unknown scheme_id: {scheme_id}"}
    lib = knowledge.documents()
    docs = []
    for doc_id in scheme["documents"]:
        d = lib[doc_id]
        docs.append({"id": doc_id, "name_en": d["en"], "name_hi": d["hi"], "required": True})
    return {
        "scheme_id": scheme_id,
        "scheme_name": scheme["name"],
        "documents": docs,
        "portal": scheme.get("portal"),
        "tip": "Keep originals plus one photocopy / clear scan. Common help desks: "
               "Common Service Centre (CSC), Gram Panchayat office, bank branch.",
    }

"""Profile validation/coercion and application-form pre-filling."""
from __future__ import annotations

import re
from datetime import date

from . import knowledge

_VALIDATORS = {
    "aadhaar": (r"^\d{12}$", "Aadhaar must be exactly 12 digits"),
    "mobile": (r"^[6-9]\d{9}$", "Mobile must be 10 digits starting with 6-9"),
    "ifsc": (r"^[A-Z]{4}0[A-Z0-9]{6}$", "IFSC must look like SBIN0001234"),
    "pincode": (r"^[1-9]\d{5}$", "PIN code must be 6 digits"),
    "bank_account": (r"^\d{9,18}$", "Bank account must be 9-18 digits"),
}
_TRUE = {"true", "yes", "y", "1", "haan", "han", "हाँ", "हां", "हा", "जी"}
_FALSE = {"false", "no", "n", "0", "nahi", "nahin", "नहीं", "ना"}


def coerce(key: str, value):
    """Validate and normalise one profile value. Returns (value, error)."""
    spec = knowledge.fields().get(key)
    if spec is None:
        return None, f"Unknown field '{key}'"
    t = spec["type"]
    try:
        if t == "bool":
            if isinstance(value, bool):
                return value, None
            s = str(value).strip().lower()
            if s in _TRUE:
                return True, None
            if s in _FALSE:
                return False, None
            return None, "Expected yes/no"
        if t == "int":
            v = int(float(str(value).replace(",", "")))
            if v < spec.get("min", v) or v > spec.get("max", v):
                return None, f"{key} out of range"
            return v, None
        if t == "enum":
            v = str(value).strip().lower().replace(" ", "_")
            if v not in spec["values"]:
                return None, f"{key} must be one of {spec['values']}"
            return v, None
        if t == "date":
            return date.fromisoformat(str(value).strip()).isoformat(), None
        v = re.sub(r"[\s-]", "", str(value)) if spec.get("validator") else str(value).strip()
        if spec.get("validator"):
            v = v.upper() if spec["validator"] == "ifsc" else v
            pattern, msg = _VALIDATORS[spec["validator"]]
            if not re.match(pattern, v):
                return None, msg
        if not v:
            return None, "Empty value"
        return v, None
    except (ValueError, TypeError):
        return None, f"Could not understand '{value}' for {key}"


def derive(profile: dict, today: date | None = None) -> dict:
    """Add derived facts (age from dob) without overwriting stated values."""
    p = dict(profile)
    today = today or date.today()
    if p.get("age") is None and p.get("dob"):
        d = date.fromisoformat(p["dob"])
        p["age"] = today.year - d.year - ((today.month, today.day) < (d.month, d.day))
    return p


def mask(key: str, value):
    spec = knowledge.fields().get(key, {})
    if spec.get("sensitive") and value:
        s = str(value)
        return "X" * max(len(s) - 4, 0) + s[-4:]
    return value


def masked_profile(profile: dict) -> dict:
    return {k: mask(k, v) for k, v in profile.items()}


def prefill(scheme_id: str, profile: dict) -> dict:
    scheme = knowledge.get_scheme(scheme_id)
    if not scheme:
        return {"error": f"Unknown scheme_id: {scheme_id}"}
    flds = knowledge.fields()
    profile = derive(profile)
    form, missing, errors = {}, [], {}
    for key in scheme["form_fields"] + scheme.get("optional_fields", []):
        required = key in scheme["form_fields"]
        val = profile.get(key)
        if val in (None, ""):
            if required:
                missing.append({"key": key, "label_en": flds[key]["en"], "label_hi": flds[key]["hi"]})
            continue
        v, err = coerce(key, val)
        if err:
            errors[key] = err
        else:
            form[key] = v
    return {"form": form, "missing_required": missing, "errors": errors}


def display_rows(scheme_id: str, form: dict) -> list[dict]:
    flds = knowledge.fields()
    return [
        {"key": k, "label_en": flds[k]["en"], "label_hi": flds[k]["hi"], "value": mask(k, v)}
        for k, v in form.items()
    ]

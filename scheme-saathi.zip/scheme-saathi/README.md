# Scheme Saathi (योजना साथी)

**A voice and text welfare-scheme agent for Indian citizens.** Talk in Hindi or a regional language; the agent works out which government schemes you may qualify for, builds your document checklist, pre-fills the application form, asks **you** to confirm before anything is submitted, and tracks follow-ups.

> Problem statement PS-01: eligible citizens miss schemes because information is scattered and forms are complex.

## What it does

| Requirement | How it is implemented |
|---|---|
| Voice or text, Hindi / regional languages | Web UI uses the browser Web Speech API for mic input and spoken replies (hi, en, mr, ta, te, bn, gu, kn, ml, pa). The LLM converses in whatever language the user uses. |
| Works out eligible schemes | `check_eligibility` tool backed by a deterministic, three-valued rule engine (`eligibility.py`) over `data/schemes.yaml`. Unknown facts give `need_more_info` plus the exact questions to ask, never a guess. |
| Document checklist | `get_document_checklist` tool (English and Hindi names, per scheme). |
| Pre-filled form | `prefill_form` tool: maps the profile onto the scheme's form, validates Aadhaar, mobile, IFSC, PIN and so on, lists missing fields, saves a DRAFT. |
| **Human confirmation before submit** | See "Safety design" below. The model has no submit tool. |
| Follow-up tracking | Auto-scheduled reminders (+7 and +30 days) after submission, plus `schedule_followup`, `list_followups`, `record_status_update`. |

Included schemes (10): PM-KISAN, Ayushman Bharat PM-JAY, PM Ujjwala, Sukanya Samriddhi, Atal Pension Yojana, PM Matru Vandana, PMAY-Gramin, Post-Matric Scholarship (SC), PM SVANidhi, e-Shram. Add more by editing YAML only.

## Architecture

```mermaid
flowchart LR
  U[Citizen<br/>voice / text] --> W[Web UI / CLI]
  W -->|/api/chat| A[Agent<br/>Claude tool-use loop]
  A -->|tool calls| T[ToolBox]
  T --> E[Eligibility engine]
  T --> D[Documents]
  T --> F[Form prefill + validation]
  T --> S[(SQLite: profile, applications,<br/>follow-ups, audit)]
  T -->|request_submission| C{{Confirmation gate}}
  C -. one-time token, UI channel only .-> W
  W -->|/api/confirm: human clicks| C
  C -->|confirmed only| P[Portal adapter]
  P --> S
```

## Safety design (human-in-the-loop)

1. The LLM has **no tool that submits**. `request_submission` only moves a draft to `PENDING_CONFIRMATION`.
2. A one-time token is sent to the **UI channel** and is never placed in the model's context, so the model cannot confirm on its own and prompt injection cannot trigger a submission.
3. Only `POST /api/confirm` (a button the person presses) or the CLI's typed `YES` can call `confirmation.confirm`.
4. The stored form is hashed at request time and re-verified at confirmation. Any later edit resets the draft and voids the token. Tokens are single-use and stored only as hashes.
5. Submission is refused if the draft is incomplete, invalid, or the rules say the person is not eligible.
6. Aadhaar and bank numbers are masked for the model and redacted from the audit log.

All of this is covered by `tests/test_confirmation.py`.

## Quickstart

```bash
git clone <your-repo-url> scheme-saathi && cd scheme-saathi
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env && export ANTHROPIC_API_KEY=sk-ant-...   # or set it in your shell

pytest -q                    # 38 tests, no API key needed
uvicorn scheme_saathi.api:app --reload   # web UI at http://localhost:8000
saathi chat --lang hi-IN     # or chat in the terminal
saathi followups --session <id> --due
```

Docker: `docker build -t scheme-saathi . && docker run -p 8000:8000 -e ANTHROPIC_API_KEY=... -v saathi:/data scheme-saathi`

Voice input needs Chrome, Edge or Android Chrome (Web Speech API). Other browsers fall back to text.

## Example (Hindi)

```
You:    मैं महाराष्ट्र का किसान हूँ, 42 साल का, मेरे पास 2 एकड़ ज़मीन है। इनकम टैक्स नहीं देता।
Saathi: आप पीएम-किसान सम्मान निधि के पात्र लगते हैं। इसमें साल में 6,000 रुपये मिलते हैं। आवेदन करना चाहेंगे?
You:    हाँ
Saathi: इन कागज़ात की ज़रूरत होगी: आधार, बैंक पासबुक, खतौनी/7-12, आधार से जुड़ा मोबाइल। आपका पूरा नाम और मोबाइल नंबर क्या है?
...
Saathi: फ़ॉर्म तैयार है। कृपया स्क्रीन पर जाँचकर "पुष्टि करें" दबाएँ।
[ confirmation slip appears: Confirm / Cancel ]
```

## API

| Endpoint | Purpose |
|---|---|
| `POST /api/chat` `{session_id, message, lang}` | Agent turn; returns `reply` and `ui_events` (e.g. `confirm_request`) |
| `POST /api/confirm` `{session_id, application_id, token, decision}` | Human confirm / cancel |
| `GET /api/applications?session_id=` | Application statuses |
| `GET /api/followups?session_id=&due_only=` | Open reminders |
| `GET /api/languages`, `/api/strings/{lang}` | UI language data |

## Project layout

```
src/scheme_saathi/
  data/schemes.yaml   scheme rules, documents, form fields (edit to add schemes)
  eligibility.py      three-valued rule engine
  forms.py            validation, coercion, pre-fill, masking
  documents.py        checklist builder
  tools.py            tool schemas + implementations
  confirmation.py     human confirmation gate
  agent.py            Claude tool-use loop
  store.py            SQLite persistence + audit log
  portal.py           submission adapter (MockPortal)
  api.py / cli.py     FastAPI app and terminal client
web/index.html        voice/text UI with confirmation slip
tests/                rules, validation, confirmation safety, agent + API flow
```

## Adding a scheme

Append an entry to `schemes.yaml` with `eligibility` (nested `all` / `any` of `{field, op, value, why}`; ops: `eq ne gte lte between in nin`), `documents`, `form_fields` and `optional_fields`. `tests/test_eligibility.py::test_every_scheme_is_well_formed` checks that every referenced field and document exists.

## Limitations and honest caveats

- **Rules are simplified summaries for screening.** Real eligibility often depends on state rules and official databases (SECC, Awaas+). Check each scheme's current guidelines and the official portal before relying on them; amounts and criteria change.
- `MockPortal` does **not** contact any government system. Most portals have no public submission API. Replace it with an official API client or an assisted-submission queue for a CSC / Gram Panchayat operator (`portal.py`).
- Profiles are stored unencrypted in SQLite and there is no login (session id only). Before real use add authentication, encryption at rest, consent and retention policies, rate limiting, and review against the DPDP Act, 2023.
- Speech uses browser APIs. For feature phones or IVR, plug a server-side STT/TTS service in front of `/api/chat`.
- Reminders are listed, not pushed. Hook `list_followups(due_only=True)` into SMS or WhatsApp.

## Roadmap

State-specific rule overlays, more schemes, DigiLocker document fetch, push reminders, IVR channel, multilingual evaluation set for rule explanations.

## License

MIT

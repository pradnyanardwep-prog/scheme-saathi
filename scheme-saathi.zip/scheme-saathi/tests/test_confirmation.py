"""The safety-critical property: nothing is submitted without the human confirming."""
from datetime import date

from scheme_saathi import confirmation
from scheme_saathi.tools import TOOL_SCHEMAS

from .conftest import FARMER, FULL_FORM


def ready_app(toolbox, store, sid="sess-0001"):
    store.merge_profile(sid, {**FARMER, **FULL_FORM})
    res, _ = toolbox.dispatch(sid, "prefill_form", {"scheme_id": "pm_kisan"})
    assert res["ready_for_confirmation"], res
    return res["application_id"]


def test_llm_has_no_submit_tool():
    names = {t["name"] for t in TOOL_SCHEMAS}
    assert not any("submit" in n and n != "request_submission" for n in names)
    assert "confirm" not in " ".join(names)


def test_request_does_not_submit_and_token_is_not_in_model_result(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    result, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    assert result["status"] == "awaiting_human_confirmation"
    token = ui[0]["token"]
    assert token not in str(result)                       # model never sees the token
    assert store.get_application(app_id)["status"] == "PENDING_CONFIRMATION"
    assert store.get_application(app_id)["reference"] is None


def test_confirm_submits_and_schedules_followups(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    res = confirmation.confirm(store, sid, app_id, ui[0]["token"], "confirm", today=date(2026, 1, 1))
    assert res["ok"] and res["reference"].startswith("MOCK-PM_KISAN-")
    assert store.get_application(app_id)["status"] == "SUBMITTED"
    assert [f["due_date"] for f in store.list_followups(sid)] == ["2026-01-08", "2026-01-31"]


def test_wrong_token_and_wrong_session_rejected(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    assert not confirmation.confirm(store, sid, app_id, "nope", "confirm")["ok"]
    assert not confirmation.confirm(store, "other-session", app_id, ui[0]["token"], "confirm")["ok"]
    assert store.get_application(app_id)["status"] == "PENDING_CONFIRMATION"


def test_token_is_single_use(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    assert confirmation.confirm(store, sid, app_id, ui[0]["token"], "confirm")["ok"]
    assert not confirmation.confirm(store, sid, app_id, ui[0]["token"], "confirm")["ok"]


def test_cancel_does_not_submit(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    assert confirmation.confirm(store, sid, app_id, ui[0]["token"], "cancel")["status"] == "CANCELLED"
    assert store.list_followups(sid) == []


def test_form_edit_after_request_voids_token(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    toolbox.dispatch(sid, "update_profile", {"fields": {"mobile": "9123456780"}})
    toolbox.dispatch(sid, "prefill_form", {"scheme_id": "pm_kisan"})
    assert store.get_application(app_id)["status"] == "DRAFT"
    assert not confirmation.confirm(store, sid, app_id, ui[0]["token"], "confirm")["ok"]


def test_tampered_stored_form_is_caught(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    store._exec("UPDATE applications SET form=? WHERE id=?", ('{"full_name":"Mallory"}', app_id))
    res = confirmation.confirm(store, sid, app_id, ui[0]["token"], "confirm")
    assert not res["ok"] and store.get_application(app_id)["status"] == "DRAFT"


def test_cannot_request_incomplete_or_ineligible(toolbox, store):
    sid = "sess-0002"
    store.merge_profile(sid, {**FARMER, "income_tax_payer": True, "full_name": "X"})
    res, _ = toolbox.dispatch(sid, "prefill_form", {"scheme_id": "pm_kisan"})
    assert not res["ready_for_confirmation"]
    out, ui = toolbox.dispatch(sid, "request_submission", {"application_id": res["application_id"]})
    assert "error" in out and ui == []


def test_status_updates_only_after_submission(toolbox, store):
    sid = "sess-0001"
    app_id = ready_app(toolbox, store, sid)
    out, _ = toolbox.dispatch(sid, "record_status_update", {"application_id": app_id, "status": "APPROVED"})
    assert "error" in out
    _, ui = toolbox.dispatch(sid, "request_submission", {"application_id": app_id})
    confirmation.confirm(store, sid, app_id, ui[0]["token"], "confirm")
    out, _ = toolbox.dispatch(sid, "record_status_update", {"application_id": app_id, "status": "APPROVED"})
    assert out["status"] == "APPROVED" and store.list_followups(sid) == []


def test_audit_log_redacts_sensitive_values(toolbox, store):
    sid = "sess-0003"
    toolbox.dispatch(sid, "update_profile", {"fields": {"aadhaar": "123456789012", "age": 30}})
    assert "123456789012" not in str(store.audit_log(sid))

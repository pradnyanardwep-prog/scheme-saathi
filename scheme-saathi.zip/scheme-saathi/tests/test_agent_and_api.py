from fastapi.testclient import TestClient

from scheme_saathi import api
from scheme_saathi.agent import SchemeSaathiAgent
from scheme_saathi.store import Store
from scheme_saathi.tools import ToolBox

from .conftest import FARMER, FULL_FORM, FakeClient, text, tool


def test_agent_tool_loop_end_to_end(store):
    fake = FakeClient([
        tool("t1", "update_profile", fields={"age": 42, "occupation": "farmer", "land_owner": True,
                                             "income_tax_payer": False}),
        tool("t2", "check_eligibility"),
        text("आप पीएम-किसान के पात्र हो सकते हैं।"),
    ])
    agent = SchemeSaathiAgent(store, client=fake)
    res = agent.chat("sess-0001", "मैं किसान हूँ, 42 साल का", "hi-IN")
    assert "पीएम-किसान" in res.reply
    assert store.get_profile("sess-0001")["occupation"] == "farmer"
    assert len(fake.calls) == 3
    # tool results are fed back to the model
    last_user = fake.calls[-1]["messages"][-1]
    assert last_user["content"][0]["type"] == "tool_result" and "pm_kisan" in last_user["content"][0]["content"]


def test_api_confirmation_flow(monkeypatch):
    store = Store(":memory:")
    store.merge_profile("sess-0001", {**FARMER, **FULL_FORM})
    fake = FakeClient([
        tool("t1", "prefill_form", scheme_id="pm_kisan"),
        tool("t2", "request_submission", application_id=1),
        text("कृपया स्क्रीन पर जाँचकर पुष्टि करें।"),
        text("आपका आवेदन जमा हो गया है।"),
    ])
    agent = SchemeSaathiAgent(store, client=fake, toolbox=ToolBox(store))
    monkeypatch.setitem(api._state, "store", store)
    monkeypatch.setitem(api._state, "agent", agent)
    c = TestClient(api.app)

    r = c.post("/api/chat", json={"session_id": "sess-0001", "message": "apply", "lang": "hi-IN"}).json()
    ev = next(e for e in r["ui_events"] if e["type"] == "confirm_request")
    assert store.get_application(1)["status"] == "PENDING_CONFIRMATION"

    bad = c.post("/api/confirm", json={"session_id": "sess-0001", "application_id": 1,
                                       "token": "wrong", "decision": "confirm"}).json()
    assert not bad["ok"]
    ok = c.post("/api/confirm", json={"session_id": "sess-0001", "application_id": 1,
                                      "token": ev["token"], "decision": "confirm", "lang": "hi-IN"}).json()
    assert ok["status"] == "SUBMITTED" and "संदर्भ" in ok["message"]
    assert len(c.get("/api/followups", params={"session_id": "sess-0001"}).json()) == 2
    assert c.get("/api/applications", params={"session_id": "sess-0001"}).json()[0]["status"] == "SUBMITTED"
    # the model is told about the human's decision on its next turn
    r2 = c.post("/api/chat", json={"session_id": "sess-0001", "message": "ok", "lang": "hi-IN"}).json()
    assert r2["reply"]
    assert any("CONFIRMED" in str(m["content"]) for m in agent.sessions["sess-0001"])

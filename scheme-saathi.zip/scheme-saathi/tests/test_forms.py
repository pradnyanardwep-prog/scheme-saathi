import pytest

from scheme_saathi import forms

from .conftest import FULL_FORM


@pytest.mark.parametrize("key,val,ok", [
    ("aadhaar", "1234 5678 9012", True), ("aadhaar", "12345", False),
    ("mobile", "9876543210", True), ("mobile", "1234567890", False),
    ("ifsc", "sbin0001234", True), ("ifsc", "SBIN1001234", False),
    ("pincode", "411001", True), ("pincode", "011001", False),
    ("age", "35", True), ("age", "200", False),
    ("bpl", "हाँ", True), ("gender", "Female", True), ("gender", "x", False),
    ("dob", "1990-02-30", False),
])
def test_coerce(key, val, ok):
    _, err = forms.coerce(key, val)
    assert (err is None) == ok


def test_unknown_field_rejected():
    assert forms.coerce("shoe_size", 9)[1]


def test_prefill_reports_missing_and_masks():
    res = forms.prefill("pm_kisan", {"full_name": "A", "aadhaar": "123456789012"})
    assert "mobile" in {m["key"] for m in res["missing_required"]}
    assert forms.masked_profile(res["form"])["aadhaar"] == "XXXXXXXX9012"


def test_prefill_complete():
    res = forms.prefill("pm_kisan", FULL_FORM)
    assert not res["missing_required"] and not res["errors"]

from scheme_saathi import eligibility, knowledge
from scheme_saathi.forms import derive

from .conftest import FARMER


def by_id(results):
    return {r["scheme_id"]: r for r in results}


def test_farmer_is_eligible_for_pm_kisan():
    r = by_id(eligibility.check_all(FARMER))
    assert r["pm_kisan"]["status"] == "eligible"
    assert r["apy"]["status"] == "not_eligible"            # age 42 is above the 18-40 entry band
    assert r["ssy"]["status"] == "need_more_info"


def test_tax_payer_excluded_with_reason():
    r = by_id(eligibility.check_all({**FARMER, "income_tax_payer": True}))
    assert r["pm_kisan"]["status"] == "not_eligible"
    assert any("tax" in x.lower() for x in r["pm_kisan"]["reasons_not_eligible"])


def test_unknown_is_not_treated_as_false():
    r = by_id(eligibility.check_all({"occupation": "farmer"}))["pm_kisan"]
    assert r["status"] == "need_more_info"
    assert {m["key"] for m in r["missing_fields"]} == {"land_owner", "income_tax_payer"}


def test_any_rule_senior_citizen_pmjay():
    r = by_id(eligibility.check_all({"age": 72, "bpl": False}))["pmjay"]
    assert r["status"] == "eligible"


def test_between_boundaries():
    for age, ok in [(17, "not_eligible"), (18, "eligible"), (40, "eligible"), (41, "not_eligible")]:
        p = {"age": age, "has_bank_account": True, "income_tax_payer": False}
        assert by_id(eligibility.check_all(p))["apy"]["status"] == ok


def test_age_derived_from_dob():
    from datetime import date
    assert derive({"dob": "2000-06-15"}, date(2026, 6, 14))["age"] == 25


def test_eligible_sorted_first():
    res = eligibility.check_all(FARMER)
    assert res[0]["status"] == "eligible"


def test_every_scheme_is_well_formed():
    flds, docs = knowledge.fields(), knowledge.documents()
    for s in knowledge.schemes():
        assert set(s["documents"]) <= set(docs), s["id"]
        assert set(s["form_fields"] + s.get("optional_fields", [])) <= set(flds), s["id"]

        def leaves(n):
            for k in ("all", "any"):
                if k in n:
                    for c in n[k]:
                        yield from leaves(c)
                    return
            yield n
        for leaf in leaves(s["eligibility"]):
            assert leaf["field"] in flds, (s["id"], leaf)

from types import SimpleNamespace

import pytest

from scheme_saathi.store import Store
from scheme_saathi.tools import ToolBox


@pytest.fixture
def store():
    return Store(":memory:")


@pytest.fixture
def toolbox(store):
    return ToolBox(store)


class FakeClient:
    """Scripted stand-in for anthropic.Anthropic: replays a list of responses."""

    def __init__(self, script):
        self.script = list(script)
        self.messages = SimpleNamespace(create=self._create)
        self.calls = []

    def _create(self, **kw):
        self.calls.append(kw)
        return self.script.pop(0)


def text(t):
    return SimpleNamespace(stop_reason="end_turn", content=[SimpleNamespace(type="text", text=t)])


def tool(id_, name, **inp):
    return SimpleNamespace(stop_reason="tool_use",
                           content=[SimpleNamespace(type="tool_use", id=id_, name=name, input=inp)])


FARMER = {"age": 42, "gender": "male", "state": "Maharashtra", "occupation": "farmer",
          "land_owner": True, "income_tax_payer": False, "bpl": False, "annual_income": 120000}

FULL_FORM = {"full_name": "Ramesh Patil", "father_or_spouse_name": "Suresh Patil", "dob": "1984-05-10",
             "mobile": "9876543210", "aadhaar": "123456789012", "bank_account": "123456789012",
             "ifsc": "SBIN0001234", "state": "Maharashtra", "district": "Pune", "land_survey_no": "123/4", "category": "obc"}
